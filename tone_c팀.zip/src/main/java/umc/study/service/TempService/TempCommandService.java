package umc.study.service.TempService;

public interface TempCommandService {
}
