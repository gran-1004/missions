package umc.study.web.dto;

import lombok.Getter;

public class TempRequest {
}
