package umc.study.domain.enums;

public enum SocialType {
    KAKAO,GOOGLE,NAVER,APPLE
}
