package umc.study.domain.enums;

public enum MemberStatus {
    ACTIVE, INACTIVE
}
